let c={isAuthenticated:!1,passwords:[],loading:!1,error:null},E=null,N=null,b=window.location.hostname,m=null,_=!1;const J=`
  /* Bitwarden-style Dropdown */
  .pm-dropdown {
    position: fixed;
    width: 300px;
    max-height: 350px;
    background: #1e2328;
    border: 1px solid #3d4148;
    border-radius: 4px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    z-index: 2147483647;
    overflow: hidden;
    font-family: 'Open Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    animation: pm-dropdown-appear 0.15s ease-out;
  }
  
  @keyframes pm-dropdown-appear {
    from { opacity: 0; transform: translateY(-4px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  .pm-dropdown-content {
    max-height: 300px;
    overflow-y: auto;
  }
  
  .pm-dropdown-content::-webkit-scrollbar {
    width: 6px;
  }
  
  .pm-dropdown-content::-webkit-scrollbar-track {
    background: #1e2328;
  }
  
  .pm-dropdown-content::-webkit-scrollbar-thumb {
    background: #3d4148;
    border-radius: 3px;
  }
  
  /* Password Item - Bitwarden style */
  .pm-password-item {
    padding: 10px 12px;
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    transition: background 0.1s ease;
    border-bottom: 1px solid #2c3036;
  }
  
  .pm-password-item:last-child {
    border-bottom: none;
  }
  
  .pm-password-item:hover {
    background: #2c3036;
  }
  
  .pm-password-item:active {
    background: #363b42;
  }
  
  /* Multi-step login suggested item */
  .pm-password-item.pm-suggested {
    background: rgba(23, 93, 220, 0.1);
    border-left: 3px solid #175ddc;
  }
  
  .pm-password-item.pm-suggested:hover {
    background: rgba(23, 93, 220, 0.2);
  }
  
  .pm-suggested-badge {
    background: #175ddc;
    color: white;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 6px;
    font-weight: 500;
  }

  .pm-password-favicon {
    width: 32px;
    height: 32px;
    background: #175ddc;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
  
  .pm-password-info {
    flex: 1;
    min-width: 0;
  }
  
  .pm-password-name {
    font-size: 14px;
    font-weight: 400;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 2px;
  }
  
  .pm-password-username {
    font-size: 12px;
    color: #8d9095;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  .pm-password-fill-icon {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #175ddc;
    cursor: pointer;
    border-radius: 4px;
    transition: background 0.1s ease;
  }
  
  .pm-password-fill-icon:hover {
    background: rgba(23, 93, 220, 0.15);
  }
  
  .pm-password-fill-icon svg {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }
  
  /* Login Required State - Bitwarden style */
  .pm-login-required {
    padding: 16px;
    border-bottom: 1px solid #2c3036;
  }
  
  .pm-login-text {
    font-size: 13px;
    color: #ffffff;
    margin-bottom: 12px;
    line-height: 1.4;
  }
  
  .pm-login-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: transparent;
    border: none;
    color: #175ddc;
    font-size: 13px;
    font-weight: 400;
    cursor: pointer;
    transition: background 0.1s ease;
    width: 100%;
    text-align: left;
    border-radius: 4px;
  }
  
  .pm-login-btn:hover {
    background: rgba(23, 93, 220, 0.1);
  }
  
  .pm-login-btn svg {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }
  
  /* Empty State */
  .pm-empty-state {
    padding: 20px 16px;
    text-align: center;
  }
  
  .pm-empty-text {
    font-size: 13px;
    color: #8d9095;
  }
  
  /* Loading State */
  .pm-loading {
    padding: 20px;
    text-align: center;
    color: #8d9095;
    font-size: 13px;
  }
  
  .pm-spinner {
    width: 20px;
    height: 20px;
    border: 2px solid #3d4148;
    border-top-color: #175ddc;
    border-radius: 50%;
    animation: pm-spin 0.6s linear infinite;
    margin: 0 auto 8px;
  }
  
  @keyframes pm-spin {
    to { transform: rotate(360deg); }
  }
  
  /* Toast */
  .pm-toast {
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    padding: 10px 16px;
    background: #1e2328;
    border: 1px solid #3d4148;
    border-radius: 4px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    z-index: 2147483647;
    font-family: 'Open Sans', -apple-system, sans-serif;
    font-size: 13px;
    color: #ffffff;
    display: flex;
    align-items: center;
    gap: 8px;
    animation: pm-toast-appear 0.2s ease-out;
  }
  
  @keyframes pm-toast-appear {
    from { opacity: 0; transform: translateX(-50%) translateY(10px); }
    to { opacity: 1; transform: translateX(-50%) translateY(0); }
  }
  
  .pm-toast.success { border-left: 3px solid #51c28a; }
  .pm-toast.error { border-left: 3px solid #c25151; }

  /* Auto-Save Popup - Bitwarden style (sağ üst köşe) */
  .pm-autosave-banner {
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 2147483647;
    background: #1e2328;
    border: 1px solid #3d4148;
    border-radius: 8px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5), 0 2px 8px rgba(0, 0, 0, 0.3);
    font-family: 'Open Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    animation: pm-popup-slide-in 0.3s ease-out;
    display: flex;
    flex-direction: column;
    padding: 16px;
    gap: 12px;
    width: 340px;
    max-width: calc(100vw - 32px);
  }

  .pm-autosave-banner.pm-closing {
    animation: pm-popup-slide-out 0.3s ease-in forwards;
  }

  @keyframes pm-popup-slide-in {
    from { transform: translateX(120%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }

  @keyframes pm-popup-slide-out {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(120%); opacity: 0; }
  }

  .pm-autosave-header {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .pm-autosave-icon {
    width: 24px;
    height: 24px;
    flex-shrink: 0;
    fill: #175ddc;
  }

  .pm-autosave-text {
    color: #ffffff;
    font-size: 13px;
    line-height: 1.4;
    flex: 1;
  }

  .pm-autosave-text strong {
    color: #8caee6;
  }

  .pm-autosave-details {
    font-size: 12px;
    color: #8d9095;
    margin-top: 2px;
  }

  .pm-autosave-username-input {
    width: 100%;
    margin-top: 8px;
    margin-bottom: 4px;
    padding: 6px 8px;
    border: 1px solid #3d4148;
    background: #111418;
    color: #e3e5e8;
    border-radius: 4px;
    font-size: 13px;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.15s ease;
  }

  .pm-autosave-username-input:focus {
    border-color: #1a6af5;
  }

  .pm-autosave-actions {
    display: flex;
    gap: 8px;
  }

  .pm-autosave-btn {
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 13px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    transition: background 0.15s ease, transform 0.1s ease;
    white-space: nowrap;
    flex: 1;
  }

  .pm-autosave-btn:active {
    transform: scale(0.97);
  }

  .pm-autosave-btn.pm-save {
    background: #175ddc;
    color: #ffffff;
  }

  .pm-autosave-btn.pm-save:hover {
    background: #1a6af5;
  }

  .pm-autosave-btn.pm-save:disabled {
    background: #3d4148;
    color: #8d9095;
    cursor: not-allowed;
  }

  .pm-autosave-btn.pm-dismiss {
    background: transparent;
    color: #8d9095;
    border: 1px solid #3d4148;
  }

  .pm-autosave-btn.pm-dismiss:hover {
    background: #2c3036;
    color: #ffffff;
  }

  .pm-autosave-close {
    background: none;
    border: none;
    color: #8d9095;
    font-size: 16px;
    cursor: pointer;
    padding: 2px 4px;
    line-height: 1;
    flex-shrink: 0;
    transition: color 0.15s ease;
    position: absolute;
    top: 8px;
    right: 8px;
  }

  .pm-autosave-close:hover {
    color: #ffffff;
  }

  /* Password Generator Suggestion Dropdown */
  .pm-password-gen {
    position: fixed;
    z-index: 2147483647;
    background: #1e2328;
    border: 1px solid #3d4148;
    border-radius: 6px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    font-family: 'Open Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    animation: pm-dropdown-appear 0.15s ease-out;
    width: 300px;
    overflow: hidden;
  }

  .pm-password-gen-header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    border-bottom: 1px solid #2c3036;
    color: #8caee6;
    font-size: 12px;
    font-weight: 600;
  }

  .pm-password-gen-header svg {
    width: 16px;
    height: 16px;
    fill: #175ddc;
    flex-shrink: 0;
  }

  .pm-password-gen-body {
    padding: 10px 12px;
    cursor: pointer;
    transition: background 0.1s ease;
  }

  .pm-password-gen-body:hover {
    background: #2c3036;
  }

  .pm-password-gen-value {
    font-family: 'Consolas', 'Monaco', monospace;
    color: #51c28a;
    font-size: 14px;
    word-break: break-all;
    letter-spacing: 0.5px;
  }

  .pm-password-gen-hint {
    color: #8d9095;
    font-size: 11px;
    margin-top: 6px;
  }

  .pm-password-gen-actions {
    display: flex;
    border-top: 1px solid #2c3036;
  }

  .pm-password-gen-btn {
    flex: 1;
    padding: 8px;
    background: none;
    border: none;
    color: #8d9095;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s ease, color 0.1s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
  }

  .pm-password-gen-btn:hover {
    background: #2c3036;
    color: #ffffff;
  }

  .pm-password-gen-btn + .pm-password-gen-btn {
    border-left: 1px solid #2c3036;
  }

  .pm-password-gen-btn svg {
    width: 14px;
    height: 14px;
    fill: currentColor;
  }
`;function Q(){if(document.getElementById("pm-overlay-styles"))return;const e=document.createElement("style");e.id="pm-overlay-styles",e.textContent=J,document.head.appendChild(e)}function Z(){return'<svg viewBox="0 0 24 24"><path d="M12 1C8.676 1 6 3.676 6 7v2H4v14h16V9h-2V7c0-3.324-2.676-6-6-6zm0 2c2.276 0 4 1.724 4 4v2H8V7c0-2.276 1.724-4 4-4zm0 10c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/></svg>'}function M(e){if(!e)return"";try{return new URL(e.startsWith("http")?e:`https://${e}`).hostname}catch{const s=e.match(/^(?:https?:\/\/)?([^\/]+)/);return s?s[1]:e}}function I(){return'<svg viewBox="0 0 24 24"><path d="M14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7zm-2 16H5V7h7V5H3v16h14v-7h-2v5h-3z"/></svg>'}function C(e){if(!e)return!1;const s=window.getComputedStyle(e);if(s.display==="none"||s.visibility==="hidden"||s.opacity==="0")return!1;const t=e.getBoundingClientRect();return t.width>0&&t.height>0}function g(e,s="success"){const t=document.querySelector(".pm-toast");t&&t.remove();const n=document.createElement("div");n.className=`pm-toast ${s}`,n.innerHTML=`<span>${s==="success"?"✓":"✕"}</span><span>${e}</span>`,document.body.appendChild(n),setTimeout(()=>{n.style.animation="pm-toast-appear 0.2s ease-out reverse",setTimeout(()=>n.remove(),200)},2e3)}async function ee(){c.loading=!0;try{if(!chrome.runtime?.id)throw new Error("Extension context invalidated");const e=await chrome.runtime.sendMessage({type:"GET_PASSWORDS_FOR_SITE",hostname:b});e?.success&&e.isAuthenticated!==!1?(c.isAuthenticated=!0,c.passwords=e.passwords||[],c.error=null):(c.isAuthenticated=!1,c.passwords=[],c.error=e?.message||null)}catch(e){const s=e instanceof Error?e.message:String(e);s.includes("Extension context invalidated")||s.includes("message port closed")||!chrome.runtime?.id?(c.isAuthenticated=!1,c.passwords=[],c.error="Eklenti yeniden yüklendi. Sayfayı yenileyin.",console.warn("[PasswordManager] Extension context invalidated - reload page")):(c.isAuthenticated=!1,c.passwords=[],c.error="Bağlantı hatası")}c.loading=!1}function v(){const e=document.querySelectorAll('input[type="password"]');return Array.from(e).filter(s=>C(s))}function x(){const e=['input[autocomplete="username"]','input[autocomplete="email"]','input[autocomplete="current-password"]','input[autocomplete="new-password"]','input[type="email"]','input[name*="user" i]','input[name*="email" i]','input[name*="login" i]','input[name*="account" i]','input[id*="user" i]','input[id*="email" i]','input[id*="login" i]','input[id*="account" i]'],s=[],t=new Set;for(const n of e)document.querySelectorAll(n).forEach(o=>{!t.has(o)&&C(o)&&!H(o)&&G(o)&&(t.add(o),s.push(o))});return s}function G(e){const s=e.type.toLowerCase(),t=(e.autocomplete||"").toLowerCase();if(s==="password"||s==="email"||["username","email","current-password","new-password","cc-name","cc-number","name","given-name","family-name"].some(r=>t.includes(r)))return!0;const o=(e.name||"").toLowerCase(),a=(e.id||"").toLowerCase();return!!["user","email","login","account","mail"].some(r=>o.includes(r)||a.includes(r))}function H(e){const s=(e.name||"").toLowerCase(),t=(e.id||"").toLowerCase(),n=(e.placeholder||"").toLowerCase(),o=e.type.toLowerCase(),a=(e.autocomplete||"").toLowerCase();return!!(o==="search"||a==="off"&&(s.includes("search")||t.includes("search")||n.includes("ara"))||s.includes("search")||t.includes("search")||n.includes("search"))}function te(){return v().length>0||U()}function U(){const e=v(),s=x();if(e.length===0&&s.length>0)for(const t of s){const n=t.closest("form"),o=n?.action?.toLowerCase()||"",a=n?.id?.toLowerCase()||"",i=n?.className?.toLowerCase()||"";if(o.includes("login")||o.includes("signin")||o.includes("auth")||a.includes("login")||a.includes("signin")||i.includes("login")||i.includes("signin")||n&&n.querySelector('button[type="submit"], input[type="submit"]'))return!0;const r=t.parentElement?.parentElement?.parentElement;if(r){const l=r.querySelectorAll("button");for(const u of l){const d=u.textContent?.toLowerCase()||"";if(d.includes("next")||d.includes("continue")||d.includes("devam")||d.includes("ileri")||d.includes("sonraki"))return!0}}}return!1}function q(){Q();const e=v(),s=x();e.forEach(t=>{if(t.getAttribute("data-pm-attached"))return;t.setAttribute("data-pm-attached","true");const n=o=>{o.stopPropagation(),V(t,"password")};t.addEventListener("focus",n),t.addEventListener("click",n)}),s.forEach(t=>{if(t.getAttribute("data-pm-attached")||!G(t))return;const n=t.closest("form");if(n&&n.querySelector('input[type="password"]'))return;t.setAttribute("data-pm-attached","true");const a=i=>{i.stopPropagation(),V(t,"username")};t.addEventListener("focus",a),t.addEventListener("click",a)})}async function V(e,s="password"){if(E&&N===e)return;y(),N=e;const t=document.createElement("div");t.className="pm-dropdown";const n=e.getBoundingClientRect(),o=window.innerWidth,a=320;let i=n.left;i+a>o-10&&(i=o-a-10),i<10&&(i=10),t.style.top=`${n.bottom+4}px`,t.style.left=`${i}px`,t.style.width=`${a}px`,t.innerHTML=`
    <div class="pm-dropdown-content">
      <div class="pm-loading">
        <div class="pm-spinner"></div>
        Yükleniyor...
      </div>
    </div>
  `,document.body.appendChild(t),E=t,await ee();const r=t.querySelector(".pm-dropdown-content");if(r)if(!c.isAuthenticated)c.error?.includes("yeniden yüklendi")||c.error?.includes("Sayfayı yenileyin")?(r.innerHTML=`
        <div class="pm-login-required">
          <div class="pm-login-text">Eklenti yeniden yüklendi. Lütfen sayfayı yenileyin.</div>
          <button class="pm-login-btn pm-reload-btn">
            🔄 Sayfayı Yenile
          </button>
        </div>
      `,r.querySelector(".pm-reload-btn")?.addEventListener("click",()=>{window.location.reload()})):c.error?.includes("Giriş yapılmamış")||c.error===null?(r.innerHTML=`
        <div class="pm-login-required">
          <div class="pm-login-text">Parolalarınızı görmek için giriş yapın</div>
          <button class="pm-login-btn">
            👤 Giriş Yap
          </button>
        </div>
      `,r.querySelector(".pm-login-btn")?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_POPUP"}),y()})):(r.innerHTML=`
        <div class="pm-login-required">
          <div class="pm-login-text">Otomatik doldurma için kasanızın kilidini açın</div>
          <button class="pm-login-btn">
            ${Z()}
            Kasayı Aç
          </button>
        </div>
      `,r.querySelector(".pm-login-btn")?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_POPUP"}),y()}));else if(c.passwords.length===0)r.innerHTML=`
      <div class="pm-empty-state">
        <div class="pm-empty-text">Bu site için kayıtlı parola yok</div>
      </div>
    `;else{let l="";if(s==="password"&&m&&m){const d=(m.name||m.websiteUrl||"P").charAt(0).toUpperCase(),f=m.name||M(m.websiteUrl);l+=`
        <div class="pm-password-item pm-suggested" data-id="${m.id}">
          <div class="pm-password-favicon">${d}</div>
          <div class="pm-password-info">
            <div class="pm-password-name">${f}</div>
            <div class="pm-password-username">${m.username} <span class="pm-suggested-badge">Önerilen</span></div>
          </div>
          <div class="pm-password-fill-icon" title="Şifreyi doldur">
            ${I()}
          </div>
        </div>
      `,c.passwords.filter(p=>p.id!==m.id).forEach(p=>{const w=(p.name||p.websiteUrl||"P").charAt(0).toUpperCase(),X=p.name||M(p.websiteUrl);l+=`
          <div class="pm-password-item" data-id="${p.id}">
            <div class="pm-password-favicon">${w}</div>
            <div class="pm-password-info">
              <div class="pm-password-name">${X}</div>
              <div class="pm-password-username">${p.username}</div>
            </div>
            <div class="pm-password-fill-icon" title="Doldur">
              ${I()}
            </div>
          </div>
        `})}else c.passwords.forEach(d=>{const f=(d.name||d.websiteUrl||"P").charAt(0).toUpperCase(),p=d.name||M(d.websiteUrl);l+=`
          <div class="pm-password-item" data-id="${d.id}">
            <div class="pm-password-favicon">${f}</div>
            <div class="pm-password-info">
              <div class="pm-password-name">${p}</div>
              <div class="pm-password-username">${d.username}</div>
            </div>
            <div class="pm-password-fill-icon" title="Doldur">
              ${I()}
            </div>
          </div>
        `});r.innerHTML=l,r.querySelectorAll(".pm-password-item").forEach(d=>{d.addEventListener("click",()=>{const f=d.getAttribute("data-id"),p=c.passwords.find(w=>w.id===f);p&&(s==="username"?(K(p.username),m=p):s==="password"&&x().length===0?(j(p.password),m=null):(Y(p.username,p.password),m=null),y())})})}}function y(){E&&(E.remove(),E=null),N=null}document.addEventListener("click",e=>{const s=e.target,t=s.closest('input[type="password"]')||s.closest('input[type="text"]')||s.closest('input[type="email"]');!s.closest(".pm-dropdown")&&!t&&y()});document.addEventListener("keydown",e=>{e.key==="Escape"&&y()});function P(e,s){try{const t=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;return t?t.call(e,s):e.value=s,e.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),e.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),!0}catch(t){return console.error("Input value set error:",t),!1}}function K(e){const s=x();if(s.length>0){const t=s[0];if(P(t,e))return g("Kullanıcı adı dolduruldu","success"),!0}return g("Kullanıcı adı alanı bulunamadı","error"),!1}function j(e){const s=v();return s.length>0&&P(s[0],e)?(g("Şifre dolduruldu","success"),!0):(g("Şifre alanı bulunamadı","error"),!1)}function Y(e,s){const t=x(),n=v();let o=!1,a=!1;if(e){const i=n[0];let r=null;if(i){const l=i.closest("form");if(l){const u=l.querySelectorAll('input[type="text"], input[type="email"], input[autocomplete="username"]');for(const d of u)if(C(d)){r=d;break}}if(!r){const u=document.querySelectorAll("input"),d=Array.from(u),f=d.indexOf(i);for(let p=f-1;p>=0;p--){const w=d[p];if((w.type==="text"||w.type==="email")&&C(w)){r=w;break}}}}!r&&t.length>0&&(r=t[0]),r&&P(r,e)&&(o=!0)}n.length>0&&s&&P(n[0],s)&&(a=!0),o||a?g("Kimlik bilgileri dolduruldu","success"):g("Doldurulacak alan bulunamadı","error")}chrome.runtime.onMessage.addListener((e,s,t)=>((e.type==="AUTOFILL"||e.type==="AUTOFILL_PASSWORD")&&(Y(e.username,e.password),t({success:!0})),e.type==="AUTOFILL_USERNAME"&&(K(e.username),e.entry&&(m=e.entry),t({success:!0})),e.type==="AUTOFILL_PASSWORD_ONLY"&&(j(e.password),m=null,t({success:!0})),e.type==="GET_PAGE_INFO"&&t({url:window.location.href,hostname:b,title:document.title,hasLoginForm:te(),isMultiStepLogin:U()&&v().length===0,hasPasswordField:v().length>0,hasUsernameField:x().length>0}),e.type==="SHOW_AUTOSAVE_BANNER"&&(D(e.username,e.password,e.hostname,e.isSignup),t({success:!0})),!0));function k(e){if(!e)return!1;const s=(e.action||"").toLowerCase(),t=(e.id||"").toLowerCase(),n=(e.className||"").toLowerCase(),o=["register","signup","sign-up","sign_up","create","join","kayit","kayıt","uye","üye"];for(const l of o)if(s.includes(l)||t.includes(l)||n.includes(l))return!0;if(e.querySelectorAll('input[autocomplete="new-password"]').length>0||e.querySelectorAll('input[type="password"]').length>=2)return!0;const r=e.querySelectorAll('button[type="submit"], input[type="submit"]');for(const l of r){const u=(l.textContent||l.value||"").toLowerCase();for(const d of o)if(u.includes(d))return!0}return!1}let h=null,T=null;function $(e=16){const s="ABCDEFGHIJKLMNOPQRSTUVWXYZ",t="abcdefghijklmnopqrstuvwxyz",n="0123456789",o="!@#$%^&*()_+-=[]{}|;:,.<>?",a=s+t+n+o,i=new Uint32Array(e);crypto.getRandomValues(i);let r="";r+=s[i[0]%s.length],r+=t[i[1]%t.length],r+=n[i[2]%n.length],r+=o[i[3]%o.length];for(let d=4;d<e;d++)r+=a[i[d]%a.length];const l=new Uint32Array(e);crypto.getRandomValues(l);const u=r.split("");for(let d=u.length-1;d>0;d--){const f=l[d]%(d+1);[u[d],u[f]]=[u[f],u[d]]}return u.join("")}function se(e){if(e.autocomplete==="new-password")return!0;const s=((e.name||"")+(e.id||"")+(e.placeholder||"")).toLowerCase();if(/new.?pass|confirm.?pass|register|signup|sign.?up|create|kayıt|kayit|tekrar|yeni.?şifre|yeni.?sifre/i.test(s))return!0;const t=e.closest("form");return!!(t&&k(t)||document.querySelectorAll('input[type="password"]').length>=2)}function ne(e){if(h&&T===e){L();return}L(),T=e;const s=$(18),t=document.createElement("div");t.className="pm-password-gen",t.innerHTML=`
    <div class="pm-password-gen-header">
      <svg viewBox="0 0 24 24">
        <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 2.18l7 3.12v4.7c0 4.83-3.23 9.36-7 10.57-3.77-1.21-7-5.74-7-10.57V6.3l7-3.12z"/>
      </svg>
      Güvenli Parola Önerisi
    </div>
    <div class="pm-password-gen-body" data-action="fill">
      <div class="pm-password-gen-value">${s}</div>
      <div class="pm-password-gen-hint">Kullanmak için tıklayın</div>
    </div>
    <div class="pm-password-gen-actions">
      <button class="pm-password-gen-btn" data-action="regenerate">
        <svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
        Yenile
      </button>
      <button class="pm-password-gen-btn" data-action="copy">
        <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
        Kopyala
      </button>
    </div>
  `;const n=e.getBoundingClientRect();t.style.left=`${n.left}px`,t.style.top=`${n.bottom+4}px`,n.left+300>window.innerWidth&&(t.style.left=`${window.innerWidth-310}px`),document.body.appendChild(t),h=t,t.querySelector('[data-action="fill"]')?.addEventListener("click",()=>{const o=t.querySelector(".pm-password-gen-value")?.textContent||"";oe(e,o),L()}),t.querySelector('[data-action="regenerate"]')?.addEventListener("click",o=>{o.stopPropagation();const a=$(18),i=t.querySelector(".pm-password-gen-value");i&&(i.textContent=a)}),t.querySelector('[data-action="copy"]')?.addEventListener("click",o=>{o.stopPropagation();const a=t.querySelector(".pm-password-gen-value")?.textContent||"";navigator.clipboard.writeText(a).then(()=>{const i=t.querySelector('[data-action="copy"]');i&&(i.innerHTML=`
          <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
          Kopyalandı!
        `,setTimeout(()=>{i&&(i.innerHTML=`
              <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
              Kopyala
            `)},2e3))})}),setTimeout(()=>{document.addEventListener("click",W)},100)}function oe(e,s){const t=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;t?t.call(e,s):e.value=s,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}));const n=e.closest("form");n&&n.querySelectorAll('input[type="password"]').forEach(a=>{a!==e&&(t?t.call(a,s):a.value=s,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})))}),g("Güvenli parola oluşturuldu ve dolduruldu","success")}function W(e){h&&!h.contains(e.target)&&T!==e.target&&L()}function L(){h&&(h.remove(),h=null,T=null,document.removeEventListener("click",W))}function F(){document.querySelectorAll('input[type="password"]').forEach(s=>{s.getAttribute("data-pm-gen-attached")||(s.setAttribute("data-pm-gen-attached","true"),se(s)&&s.addEventListener("focus",()=>{setTimeout(()=>{(!s.value||s.value.length<4)&&ne(s)},300)}))})}async function D(e,s,t,n){if(!_&&chrome.runtime?.id)try{if(n)R(e,s,t);else{const o=await chrome.runtime.sendMessage({type:"CHECK_CREDENTIAL_EXISTS",hostname:t,username:e});o?.success&&!o.exists&&R(e,s,t)}}catch{}}function R(e,s,t){const n=document.querySelector(".pm-autosave-banner");n&&n.remove(),_=!0;const o=document.createElement("div");o.className="pm-autosave-banner";const a=t.replace(/^www\./,"");o.innerHTML=`
    <button class="pm-autosave-close" title="Kapat">✕</button>
    <div class="pm-autosave-header">
      <svg class="pm-autosave-icon" viewBox="0 0 24 24">
        <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 2.18l7 3.12v4.7c0 4.83-3.23 9.36-7 10.57-3.77-1.21-7-5.74-7-10.57V6.3l7-3.12zM11 7v2h2V7h-2zm0 4v6h2v-6h-2z"/>
      </svg>
      <div class="pm-autosave-text">
        <div><strong>Parola Yöneticisi</strong></div>
        <div>Bu parolayı kaydetmek ister misiniz?</div>
        <input type="text" class="pm-autosave-username-input" value="${e&&e!=="-"?e:""}" placeholder="Kullanıcı adı veya E-posta" />
        <div class="pm-autosave-details">${a}</div>
      </div>
    </div>
    <div class="pm-autosave-actions">
      <button class="pm-autosave-btn pm-save">Kaydet</button>
      <button class="pm-autosave-btn pm-dismiss">Hayır</button>
    </div>
  `,document.body.appendChild(o);const i=o.querySelector(".pm-save");i?.addEventListener("click",async()=>{const r=i,l=o.querySelector(".pm-autosave-username-input"),u=(l?l.value.trim():e)||"-";r.disabled=!0,r.textContent="Kaydediliyor...";try{const d=await chrome.runtime.sendMessage({type:"SAVE_PASSWORD",name:a,username:u,password:s,websiteUrl:`https://${t}`});d?.success?(r.textContent="✓ Kaydedildi",r.style.background="#51c28a",g("Parola kasaya kaydedildi","success"),chrome.runtime.sendMessage({type:"CLEAR_PENDING_CREDENTIALS"}).catch(()=>{}),setTimeout(()=>z(o),1500)):(r.textContent="Hata!",r.style.background="#c25151",r.disabled=!1,g(d?.message||"Kaydetme başarısız","error"),setTimeout(()=>{r.textContent="Kaydet",r.style.background="#175ddc"},2e3))}catch{r.textContent="Hata!",r.disabled=!1,g("Bağlantı hatası","error"),setTimeout(()=>{r.textContent="Kaydet",r.style.background="#175ddc"},2e3)}}),o.querySelector(".pm-dismiss")?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"CLEAR_PENDING_CREDENTIALS"}).catch(()=>{}),z(o)}),o.querySelector(".pm-autosave-close")?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"CLEAR_PENDING_CREDENTIALS"}).catch(()=>{}),z(o)})}function z(e){e.classList.add("pm-closing"),setTimeout(()=>{e.remove(),_=!1},300)}function re(e){if(e.getAttribute("data-pm-submit-attached"))return;e.setAttribute("data-pm-submit-attached","true"),e.addEventListener("submit",()=>{const n=A(e);n&&S(n.username,n.password,k(e))},{capture:!0}),e.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]').forEach(n=>{if(n.getAttribute("data-pm-click-attached"))return;n.setAttribute("data-pm-click-attached","true");const o=(n.textContent||n.value||"").toLowerCase();(/giriş|login|sign.?in|log.?in|oturum|submit|gönder|devam|continue|enter|kayıt|register|sign.?up|oluştur|create/i.test(o)||n.getAttribute("type")==="submit")&&n.addEventListener("click",()=>{setTimeout(()=>{const i=A(e);i&&S(i.username,i.password,k(e))},100)},{capture:!0})}),e.querySelectorAll('input[type="password"]').forEach(n=>{n.getAttribute("data-pm-keydown-attached")||(n.setAttribute("data-pm-keydown-attached","true"),n.addEventListener("keydown",o=>{o.key==="Enter"&&setTimeout(()=>{const a=A(e);a&&S(a.username,a.password,k(e))},100)}))})}function A(e){const s=e.querySelectorAll('input[type="password"]');if(s.length===0)return null;let t="";for(const a of s)if(a.value){t=a.value;break}if(!t)return null;let n="";const o=['input[autocomplete="username"]','input[autocomplete="email"]','input[type="email"]','input[name*="user" i]','input[name*="email" i]','input[name*="login" i]','input[name*="account" i]','input[id*="user" i]','input[id*="email" i]','input[id*="login" i]','input[id*="account" i]','input[type="text"]','input[type="tel"]'];for(const a of o){const i=e.querySelectorAll(a);for(const r of i)if(r.value&&r.type!=="password"&&!H(r)){n=r.value;break}if(n)break}return n===t&&(n=""),{username:n||"",password:t}}function O(){const e=document.querySelectorAll("form");for(const t of e){const n=A(t);if(n)return n}const s=document.querySelectorAll('input[type="password"]');for(const t of s){if(!t.value)continue;const n=t.closest("div[class], section, main, body")||document.body,o=['input[autocomplete="username"]','input[autocomplete="email"]','input[type="email"]','input[name*="user" i]','input[name*="email" i]','input[type="text"]','input[type="tel"]'];let a="";for(const i of o){const r=n.querySelectorAll(i);for(const l of r)if(l.value&&l.type!=="password"&&!H(l)){a=l.value;break}if(a)break}return a===t.value&&(a=""),{username:a,password:t.value}}return null}function S(e,s,t){chrome.runtime?.id&&s&&(chrome.runtime.sendMessage({type:"CREDENTIAL_SUBMITTED",username:e,password:s,hostname:b,isSignup:t}).catch(()=>{}),setTimeout(()=>{D(e,s,b,t)},1500))}function B(){document.querySelectorAll("form").forEach(t=>{t.querySelector('input[type="password"]')&&re(t)}),document.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]').forEach(t=>{if(t.getAttribute("data-pm-orphan-click")||t.closest("form"))return;const n=(t.textContent||t.value||"").toLowerCase();/giriş|login|sign.?in|log.?in|oturum|submit|gönder|devam|continue|kayıt|register|sign.?up|oluştur|create/i.test(n)&&(t.setAttribute("data-pm-orphan-click","true"),t.addEventListener("click",()=>{setTimeout(()=>{const a=O();if(a){const i=/kayıt|register|sign.?up|oluştur|create|join/i.test(n);S(a.username,a.password,i)}},100)},{capture:!0}))}),document.querySelectorAll('input[type="password"]').forEach(t=>{t.getAttribute("data-pm-keydown-attached")||t.closest("form")||(t.setAttribute("data-pm-keydown-attached","true"),t.addEventListener("keydown",n=>{n.key==="Enter"&&setTimeout(()=>{const o=O();o&&S(o.username,o.password,!1)},100)}))})}function ae(){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{setTimeout(()=>{q(),B(),F()},300)}):setTimeout(()=>{q(),B(),F()},300),new MutationObserver(()=>{q(),B(),F()}).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("beforeunload",()=>{const s=O();if(s&&chrome.runtime?.id){const t=document.querySelectorAll("form");let n=!1;for(const o of t)if(o.querySelector('input[type="password"]')&&k(o)){n=!0;break}chrome.runtime.sendMessage({type:"CREDENTIAL_SUBMITTED",username:s.username,password:s.password,hostname:b,isSignup:n}).catch(()=>{})}}),window.addEventListener("message",s=>{s.data?.type==="PM_EXTENSION_REFRESH_CACHE"&&chrome.runtime?.id&&chrome.runtime.sendMessage({type:"CLEAR_CACHE"}).catch(()=>{})}),setTimeout(()=>{const s=v().length>0,t=U();(s||t)&&chrome.runtime.sendMessage({type:"LOGIN_FORM_DETECTED",hostname:b,isMultiStep:t&&!s}).catch(()=>{}),chrome.runtime.sendMessage({type:"GET_PENDING_CREDENTIALS"}).then(n=>{n?.success&&n.hasPending&&D(n.username,n.password,n.hostname,n.isSignup)}).catch(n=>{console.log("[PM-DEBUG] GET_PENDING_CREDENTIALS error:",n)})},500)}ae();
