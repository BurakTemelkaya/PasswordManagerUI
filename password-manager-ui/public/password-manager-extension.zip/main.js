import{u as E,a as L,b as T,r as d,j as e,L as _,f as U,l as B,d as A,A as G,c as R,g as F,e as M,h as H,i as V,k as Z,R as Q,m as v,n as J,o as X,S as ee,N as ae,B as se,V as re,P as ne,p as te}from"./chunks/Settings-Dj1KQ3M0.js";import"./chunks/config-DmK0IJcx.js";const ie=({onLogout:r,onAddPassword:t,onViewPassword:l,onEditPassword:a,onSettings:p})=>{const u=E(),{passwords:s,decryptedPasswords:b,loading:N,error:x,fetchPasswords:S,checkForUpdates:h}=L(),{lock:f}=T(),[c,C]=d.useState(""),I=localStorage.getItem("userName")||"Kullanıcı",[P,m]=d.useState(null),[o,w]=d.useState(1),D=12,g=d.useMemo(()=>{if(w(1),!c.trim())return s;const n=c.toLowerCase();return s.filter(j=>{const z=b.get(j.id);return z?z.name.toLowerCase().includes(n)||z.username.toLowerCase().includes(n)||z.websiteUrl.toLowerCase().includes(n):!1})},[s,c,b]),i=Math.ceil(g.length/D),y=g.slice((o-1)*D,o*D),k=n=>{w(n),window.scrollTo({top:0,behavior:"smooth"})},$=async()=>{window.confirm("Çıkış yapmak istediğinize emin misiniz?")&&(await B(),r?r():u("/login"))},q=async n=>{if(window.confirm("Bu parolayı silmek istediğinize emin misiniz?"))try{m(null),await A({id:n}),await S(!0)}catch(j){j instanceof G?m(j.getUserMessage()):m("Silme işlemi başarısız"),console.error(j)}};return N&&s.length===0?e.jsx("div",{className:"loading",children:"Yükleniyor..."}):e.jsxs("div",{className:"container",children:[e.jsxs("header",{className:"header",children:[e.jsx("h1",{children:"Parolalarım"}),e.jsxs("div",{className:"header-actions",children:[e.jsx(_,{to:"/download",className:"btn btn-info",style:{marginRight:"8px",textDecoration:"none"},title:"Tarayıcı eklentisini indir",children:"🔌 Eklenti"}),e.jsx("button",{onClick:()=>h(!0),className:"btn btn-secondary",style:{marginRight:"8px"},title:"Şimdi Senkronize Et",children:"🔄"}),e.jsx("button",{onClick:()=>{p?p():u("/settings")},className:"btn btn-secondary",style:{marginRight:"8px"},title:"Ayarlar",children:"⚙️"}),e.jsxs("span",{className:"user-name",children:["👤 ",I]}),e.jsx("button",{onClick:f,className:"btn btn-warning",style:{marginRight:"8px"},title:"Kasayı Kilitle",children:"🔒 Kilitle"}),e.jsx("button",{onClick:$,className:"btn btn-logout",children:"Çıkış Yap"})]})]}),e.jsxs("main",{className:"main",children:[e.jsx("div",{className:"actions",children:e.jsx("button",{onClick:()=>{t?t():u("/passwords/add")},className:"btn btn-primary",children:"+ Yeni Parola"})}),e.jsx("div",{className:"search-box",style:{marginBottom:"16px"},children:e.jsx("input",{type:"text",placeholder:"Parola ara... (ad, kullanıcı adı, website)",value:c,onChange:n=>C(n.target.value),style:{width:"100%",padding:"12px 16px",borderRadius:"8px",border:"1px solid var(--border-color)",background:"var(--bg-input)",color:"var(--text-primary)",fontSize:"14px"}})}),(x||P)&&e.jsx("div",{className:"alert alert-error",children:x||P}),g.length===0?e.jsx("div",{className:"empty-state",children:c?e.jsxs("p",{children:['"',c,'" için sonuç bulunamadı']}):e.jsxs(e.Fragment,{children:[e.jsx("p",{children:"Henüz parola eklememişsiniz"}),e.jsx("button",{onClick:()=>{t?t():u("/passwords/add")},className:"btn btn-primary",children:"İlk parolayı ekleyin"})]})}):e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"password-grid",children:y.map(n=>{const j=b.get(n.id);return e.jsxs("div",{className:"password-card",children:[e.jsx("h3",{children:j?.name||"Parola"}),e.jsx("p",{className:"website",children:j?.websiteUrl||"-"}),e.jsxs("p",{className:"username",children:["Kullanıcı: ",j?.username||"-"]}),e.jsxs("p",{className:"password-date",children:["Oluşturulma: ",U(n.createdDate)]}),e.jsxs("div",{className:"actions",children:[e.jsx("button",{onClick:()=>{l?l(n.id):u(`/passwords/${n.id}`)},className:"btn btn-small btn-info",children:"Görüntüle"}),e.jsx("button",{onClick:()=>{a?a(n.id):u(`/passwords/${n.id}/edit`)},className:"btn btn-small btn-warning",children:"Düzenle"}),e.jsx("button",{onClick:()=>q(n.id),className:"btn btn-small btn-danger",children:"Sil"})]})]},n.id)})}),i>1&&e.jsxs("div",{className:"pagination",style:{display:"flex",justifyContent:"center",alignItems:"center",gap:"8px",marginTop:"24px"},children:[e.jsx("button",{onClick:()=>k(o-1),disabled:o===1,className:"btn btn-secondary",style:{opacity:o===1?.5:1,marginTop:0},children:"« Önceki"}),Array.from({length:i},(n,j)=>j+1).filter(n=>n===1||n===i||n>=o-2&&n<=o+2).map((n,j,z)=>{const W=j>0&&n-z[j-1]>1;return e.jsxs("div",{style:{display:"flex",alignItems:"center"},children:[W&&e.jsx("span",{style:{margin:"0 8px",color:"var(--text-muted)"},children:"..."}),e.jsx("button",{onClick:()=>k(n),className:`btn ${o===n?"btn-primary":"btn-secondary"}`,style:{minWidth:"32px",marginTop:0},children:n})]},n)}),e.jsx("button",{onClick:()=>k(o+1),disabled:o===i,className:"btn btn-secondary",style:{opacity:o===i?.5:1,marginTop:0},children:"Sonraki »"})]})]}),e.jsxs("div",{style:{textAlign:"center",marginTop:"16px",color:"var(--text-muted)",fontSize:"13px"},children:["Toplam: ",s.length," parola ",c&&`(${g.length} sonuç)`,i>1&&` • Sayfa ${o} / ${i}`]})]})]})},O=({onSuccess:r,onCancel:t})=>{const l=E(),{fetchPasswords:a}=L(),{id:p}=R(),u=!!p,[s,b]=d.useState({name:"",username:"",password:"",description:"",websiteUrl:""}),[N,x]=d.useState(!1),[S,h]=d.useState(u),[f,c]=d.useState(null),[C,I]=d.useState(!1);d.useEffect(()=>{u&&p&&P()},[p,u]);const P=async()=>{try{h(!0);const g=sessionStorage.getItem("encryptionKey");if(!g){c("Kasa kilitli. Lütfen yeniden giriş yapın."),h(!1);return}const i=await F(p),y=await M({encryptedName:i.encryptedName,encryptedUserName:i.encryptedUserName,encryptedPassword:i.encryptedPassword,encryptedDescription:i.encryptedDescription,encryptedWebSiteUrl:i.encryptedWebSiteUrl},g,i.iv);b({name:y.name,username:y.username,password:y.password,description:y.description,websiteUrl:y.websiteUrl})}catch(g){c("Parola yüklenemedi"),console.error(g)}finally{h(!1)}},m=g=>{const{name:i,value:y}=g.target;b(k=>({...k,[i]:y}))},o=()=>{const i="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*_+-=[]{}|:;<>?,./";let y="";for(let k=0;k<16;k++)y+=i.charAt(Math.floor(Math.random()*i.length));b(k=>({...k,password:y}))},w=async g=>{if(g.preventDefault(),c(null),!s.name||!s.username||!s.password){c("Ad, kullanıcı adı ve parola gereklidir");return}try{x(!0);const i=sessionStorage.getItem("encryptionKey");if(!i){c("Kasa kilitli. Lütfen yeniden giriş yapın."),h(!1);return}const y=await H({name:s.name,username:s.username,password:s.password,description:s.description,websiteUrl:s.websiteUrl},i);if(u&&p){const k={id:p,...y};await V(k)}else await Z(y);await a(!0),r?r():l("/")}catch(i){i instanceof G?c(i.getUserMessage()):i instanceof Error?c(i.message):c("İşlem başarısız. Lütfen tekrar deneyiniz."),console.error(i)}finally{x(!1)}},D=async()=>{if(window.confirm("Bu parolayı silmek istediğinize emin misiniz?"))try{x(!0),await A({id:p}),await a(!0),r?r():l("/")}catch(g){console.error(g),c("Silme işlemi başarısız."),x(!1)}};return S?e.jsx("div",{className:"loading",children:"Yükleniyor..."}):e.jsxs("div",{className:"container",children:[e.jsxs("header",{className:"header",children:[e.jsx("button",{onClick:()=>{t?t():l("/")},className:"btn btn-back",children:"← Geri"}),e.jsx("h1",{children:u?"Parolayı Düzenle":"Yeni Parola Ekle"})]}),e.jsx("main",{className:"main",children:e.jsxs("form",{onSubmit:w,className:"password-form",children:[f&&e.jsx("div",{className:"alert alert-error",children:f}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{htmlFor:"name",children:["Parola Adı ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{id:"name",type:"text",name:"name",value:s.name,onChange:m,placeholder:"örn: GitHub Şifresi",required:!0})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"websiteUrl",children:"Website URL"}),e.jsx("input",{id:"websiteUrl",type:"url",name:"websiteUrl",value:s.websiteUrl,onChange:m,placeholder:"https://github.com"})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{htmlFor:"username",children:["Kullanıcı Adı ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{id:"username",type:"text",name:"username",value:s.username,onChange:m,placeholder:"Kullanıcı adını girin",required:!0})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{htmlFor:"password",children:["Parola ",e.jsx("span",{className:"required",children:"*"})]}),e.jsxs("div",{className:"password-input-wrapper",children:[e.jsx("input",{id:"password",type:C?"text":"password",name:"password",value:s.password,onChange:m,placeholder:"Parolayı girin",required:!0}),e.jsx("button",{type:"button",onClick:()=>I(!C),className:"btn btn-icon",title:C?"Gizle":"Göster",children:C?"🙈":"👁️"}),e.jsx("button",{type:"button",onClick:o,className:"btn btn-icon",title:"Parola üret",children:"🔐"})]}),e.jsx("small",{children:"Güvenli bir parola için 🔐 butonuna tıklayın"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"description",children:"Açıklama"}),e.jsx("textarea",{id:"description",name:"description",value:s.description,onChange:m,placeholder:"Notlar (isteğe bağlı)",rows:3,style:{padding:"12px 16px",width:"100%",boxSizing:"border-box"}})]}),e.jsxs("div",{className:"form-actions",children:[u&&e.jsx("button",{type:"button",onClick:D,className:"btn",style:{backgroundColor:"#ef4444",color:"white",marginRight:"auto"},disabled:N,children:"Sil"}),e.jsx("button",{type:"submit",className:"btn btn-primary",disabled:N,children:N?"Kaydediliyor...":u?"Güncelle":"Ekle"}),e.jsx("button",{type:"button",onClick:()=>{t?t():l("/")},className:"btn btn-secondary",children:"İptal"})]})]})})]})},oe=()=>e.jsx(O,{}),le=()=>{const{id:r}=R(),t=E(),{passwords:l,fetchPasswords:a}=L(),[p,u]=d.useState(null),[s,b]=d.useState(null),[N,x]=d.useState(!0),[S,h]=d.useState(null),[f,c]=d.useState(!1);d.useEffect(()=>{r&&C()},[r,l]);const C=async()=>{try{x(!0),h(null);const m=sessionStorage.getItem("encryptionKey");if(!m){h("Kasa kilitli. Lütfen yeniden giriş yapın."),x(!1);return}let o=l.find(w=>w.id===r);if(!o)try{o=await F(r)}catch(w){console.error(w),h("Parola bulunamadı."),x(!1);return}if(!o){h("Parola bulunamadı"),x(!1);return}if(u(o),!o.iv){console.warn("⚠️ IV BULUNAMADI"),h("Bu parola eski formatta."),x(!1);return}try{const w=await M({encryptedName:o.encryptedName,encryptedUserName:o.encryptedUserName,encryptedPassword:o.encryptedPassword,encryptedDescription:o.encryptedDescription,encryptedWebSiteUrl:o.encryptedWebSiteUrl},m,o.iv);b(w)}catch(w){console.error("❌ Decrypt hatası:",w),h(`Şifre çözme başarısız: ${w.message}`)}}catch(m){console.error("❌ Hata:",m),h(`İşlem başarısız: ${m.message||m}`)}finally{x(!1)}},I=async()=>{if(window.confirm("Bu parolayı silmek istediğinize emin misiniz?"))try{x(!0),await A({id:r}),await a(!0),t("/")}catch(m){console.error(m),h("Silme işlemi başarısız."),x(!1)}},P=m=>{navigator.clipboard.writeText(m),alert("Kopyalandı!")};return N?e.jsx("div",{className:"loading",children:"Yükleniyor..."}):S||!p?e.jsxs("div",{className:"container",children:[e.jsx("div",{className:"alert alert-error",children:S||"Parola bulunamadı"}),e.jsx("button",{onClick:()=>t("/"),className:"btn btn-primary",children:"Geri Dön"})]}):e.jsxs("div",{className:"container",children:[e.jsxs("header",{className:"header",children:[e.jsx("button",{onClick:()=>t("/"),className:"btn btn-back",children:"← Geri"}),e.jsx("h1",{children:s?.name||"Parola"})]}),e.jsxs("main",{className:"main",children:[e.jsxs("div",{className:"password-details",children:[e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Website"}),e.jsx("p",{children:s?.websiteUrl||"-"})]}),e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Kullanıcı Adı"}),e.jsxs("div",{className:"detail-with-action",children:[e.jsx("p",{children:s?.username||"-"}),e.jsx("button",{onClick:()=>P(s?.username||""),className:"btn btn-small btn-secondary",children:"Kopyala"})]})]}),e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Parola"}),e.jsxs("div",{className:"detail-with-action",children:[e.jsx("p",{children:f?s?.password:"••••••••"}),e.jsx("button",{onClick:()=>c(!f),className:"btn btn-small btn-secondary",children:f?"Gizle":"Göster"}),e.jsx("button",{onClick:()=>P(s?.password||""),className:"btn btn-small btn-secondary",children:"Kopyala"})]})]}),s?.description&&e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Açıklama"}),e.jsx("p",{children:s.description})]}),e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Oluşturulma Tarihi"}),e.jsx("p",{children:U(p.createdDate)})]}),p.updatedDate&&e.jsxs("div",{className:"detail-group",children:[e.jsx("label",{children:"Son Güncellenme Tarihi"}),e.jsx("p",{children:U(p.updatedDate)})]})]}),e.jsxs("div",{className:"actions",children:[e.jsx("button",{onClick:I,className:"btn",style:{backgroundColor:"#ef4444",color:"white",marginRight:"auto"},children:"Sil"}),e.jsx("button",{onClick:()=>t(`/passwords/${r}/edit`),className:"btn btn-warning",children:"Düzenle"}),e.jsx("button",{onClick:()=>t("/"),className:"btn btn-secondary",children:"Kapat"})]})]})]})},de=()=>{const r=E();return e.jsx("div",{className:"container",children:e.jsxs("div",{className:"not-found",children:[e.jsx("h1",{children:"404"}),e.jsx("p",{children:"Sayfa bulunamadı"}),e.jsx("button",{onClick:()=>r("/"),className:"btn btn-primary",children:"Ana Sayfaya Dön"})]})})},ce=()=>{const r=E(),t=()=>{const l=document.createElement("a");l.href="/password-manager-extension.zip",l.download="password-manager-extension.zip",document.body.appendChild(l),l.click(),document.body.removeChild(l)};return e.jsxs("div",{className:"download-page",children:[e.jsxs("div",{className:"download-container",children:[e.jsxs("header",{className:"download-header",style:{position:"relative"},children:[e.jsx("button",{onClick:()=>r("/"),className:"btn-back-absolute",style:{position:"absolute",left:0,top:0,background:"rgba(255,255,255,0.1)",border:"none",color:"white",padding:"8px 16px",borderRadius:"8px",cursor:"pointer",display:"flex",alignItems:"center",gap:"4px"},children:"← Geri"}),e.jsx("div",{className:"download-logo",children:"🔐"}),e.jsx("h1",{children:"Parola Yöneticisi"}),e.jsx("p",{className:"download-subtitle",children:"Zero-Knowledge güvenlikli tarayıcı eklentisi"})]}),e.jsxs("section",{className:"download-features",children:[e.jsxs("div",{className:"feature-card",children:[e.jsx("span",{className:"feature-icon",children:"🔒"}),e.jsx("h3",{children:"Zero-Knowledge"}),e.jsx("p",{children:"Parolalarınız cihazınızda şifrelenir, sunucuda asla açık metin olarak tutulmaz."})]}),e.jsxs("div",{className:"feature-card",children:[e.jsx("span",{className:"feature-icon",children:"⚡"}),e.jsx("h3",{children:"Otomatik Doldurma"}),e.jsx("p",{children:"Web sitelerine tek tıkla giriş yapın, form alanlarını otomatik doldurun."})]}),e.jsxs("div",{className:"feature-card",children:[e.jsx("span",{className:"feature-icon",children:"🔄"}),e.jsx("h3",{children:"Import/Export"}),e.jsx("p",{children:"Chrome, Firefox, Bitwarden, LastPass'tan parolalarınızı kolayca aktarın."})]}),e.jsxs("div",{className:"feature-card",children:[e.jsx("span",{className:"feature-icon",children:"🛡️"}),e.jsx("h3",{children:"Güçlü Şifreleme"}),e.jsx("p",{children:"AES-256-GCM şifreleme ve PBKDF2 (600.000 iterasyon) ile korunun."})]})]}),e.jsxs("section",{className:"download-section",children:[e.jsx("h2",{children:"Tarayıcı Eklentisini İndirin"}),e.jsx("div",{className:"download-options",children:e.jsxs("div",{className:"download-card",children:[e.jsxs("div",{className:"browser-icons",children:[e.jsx("span",{className:"browser-icon",title:"Chrome",children:"🌐"}),e.jsx("span",{className:"browser-icon",title:"Edge",children:"💠"}),e.jsx("span",{className:"browser-icon",title:"Brave",children:"🦁"})]}),e.jsx("h3",{children:"Chrome / Edge / Brave"}),e.jsx("p",{children:"Chromium tabanlı tarayıcılar için"}),e.jsx("button",{onClick:t,className:"download-btn",children:"📦 Eklentiyi İndir (.zip)"})]})}),e.jsxs("div",{className:"install-guide",children:[e.jsx("h3",{children:"📋 Kurulum Adımları"}),e.jsxs("ol",{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"İndirin:"})," Yukarıdaki butona tıklayarak ZIP dosyasını indirin."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Çıkartın:"})," ZIP dosyasını bir klasöre çıkartın."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Eklentiler sayfasını açın:"}),e.jsx("code",{children:"chrome://extensions"})," adresine gidin."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Geliştirici modu:"}),' Sağ üst köşedeki "Geliştirici modu"nu açın.']}),e.jsxs("li",{children:[e.jsx("strong",{children:"Yükleyin:"}),' "Paketlenmemiş öğe yükle" butonuna tıklayın ve çıkarttığınız klasörü seçin.']}),e.jsxs("li",{children:[e.jsx("strong",{children:"Hazır!"})," Eklenti simgesi tarayıcı araç çubuğunda görünecektir."]})]})]})]}),e.jsxs("section",{className:"download-actions",children:[e.jsx("p",{children:"Zaten hesabınız var mı?"}),e.jsx("button",{onClick:()=>r("/login"),className:"btn-secondary",children:"Giriş Yap"}),e.jsx("button",{onClick:()=>r("/register"),className:"btn-primary",children:"Kayıt Ol"})]}),e.jsx("footer",{className:"download-footer",children:e.jsxs("p",{children:["🔐 Açık kaynak parola yöneticisi |",e.jsx("a",{href:"https://github.com/BurakTemelkaya/PasswordManagerUI",target:"_blank",rel:"noopener noreferrer",children:"GitHub"})]})})]}),e.jsx("style",{children:`
        .download-page {
          min-height: 100vh;
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
          padding: 40px 20px;
        }

        .download-container {
          max-width: 900px;
          margin: 0 auto;
        }

        .download-header {
          text-align: center;
          margin-bottom: 48px;
        }

        .download-logo {
          font-size: 64px;
          margin-bottom: 16px;
        }

        .download-header h1 {
          font-size: 36px;
          color: #fff;
          margin-bottom: 8px;
        }

        .download-subtitle {
          font-size: 18px;
          color: #94a3b8;
        }

        .download-features {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-bottom: 48px;
        }

        .feature-card {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          padding: 24px;
          text-align: center;
          transition: transform 0.2s, border-color 0.2s;
        }

        .feature-card:hover {
          transform: translateY(-4px);
          border-color: rgba(59, 130, 246, 0.5);
        }

        .feature-icon {
          font-size: 40px;
          display: block;
          margin-bottom: 12px;
        }

        .feature-card h3 {
          color: #fff;
          font-size: 16px;
          margin-bottom: 8px;
        }

        .feature-card p {
          color: #94a3b8;
          font-size: 13px;
          line-height: 1.5;
        }

        .download-section {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 20px;
          padding: 32px;
          margin-bottom: 32px;
        }

        .download-section h2 {
          color: #fff;
          text-align: center;
          margin-bottom: 24px;
          font-size: 24px;
        }

        .download-options {
          display: flex;
          justify-content: center;
          gap: 24px;
          margin-bottom: 32px;
        }

        .download-card {
          background: rgba(59, 130, 246, 0.1);
          border: 2px solid rgba(59, 130, 246, 0.3);
          border-radius: 16px;
          padding: 32px;
          text-align: center;
          min-width: 280px;
        }

        .browser-icons {
          display: flex;
          justify-content: center;
          gap: 12px;
          margin-bottom: 16px;
        }

        .browser-icon {
          font-size: 32px;
        }

        .download-card h3 {
          color: #fff;
          font-size: 18px;
          margin-bottom: 8px;
        }

        .download-card p {
          color: #94a3b8;
          font-size: 14px;
          margin-bottom: 20px;
        }

        .download-btn {
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: #fff;
          border: none;
          border-radius: 12px;
          padding: 14px 28px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: transform 0.2s, box-shadow 0.2s;
        }

        .download-btn:hover {
          transform: scale(1.05);
          box-shadow: 0 8px 24px rgba(59, 130, 246, 0.4);
        }

        .install-guide {
          background: rgba(0, 0, 0, 0.2);
          border-radius: 12px;
          padding: 24px;
        }

        .install-guide h3 {
          color: #fff;
          margin-bottom: 16px;
          font-size: 18px;
        }

        .install-guide ol {
          color: #cbd5e1;
          padding-left: 24px;
          margin: 0;
        }

        .install-guide li {
          margin-bottom: 12px;
          line-height: 1.6;
        }

        .install-guide strong {
          color: #fff;
        }

        .install-guide code {
          background: rgba(59, 130, 246, 0.2);
          padding: 2px 8px;
          border-radius: 4px;
          font-family: monospace;
          color: #60a5fa;
        }

        .download-actions {
          text-align: center;
          margin-bottom: 32px;
        }

        .download-actions p {
          color: #94a3b8;
          margin-bottom: 16px;
        }

        .download-actions button {
          margin: 0 8px;
          padding: 12px 24px;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
        }

        .btn-secondary {
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.2);
          color: #fff;
        }

        .btn-secondary:hover {
          background: rgba(255, 255, 255, 0.1);
        }

        .btn-primary {
          background: #3b82f6;
          border: none;
          color: #fff;
        }

        .btn-primary:hover {
          background: #2563eb;
        }

        .download-footer {
          text-align: center;
          color: #64748b;
          font-size: 14px;
        }

        .download-footer a {
          color: #60a5fa;
          text-decoration: none;
          margin-left: 8px;
        }

        .download-footer a:hover {
          text-decoration: underline;
        }

        @media (max-width: 768px) {
          .download-header h1 {
            font-size: 28px;
          }

          .download-features {
            grid-template-columns: 1fr 1fr;
          }

          .download-card {
            min-width: auto;
            width: 100%;
          }
        }

        @media (max-width: 480px) {
          .download-features {
            grid-template-columns: 1fr;
          }
        }
      `})]})},me=()=>{const{unlock:r}=T(),[t,l]=d.useState(""),[a,p]=d.useState(!1),[u,s]=d.useState(null),[b,N]=d.useState(null);d.useEffect(()=>{const f=localStorage.getItem("userName");f&&N(f)},[]);const x=async f=>{if(f.preventDefault(),!t)return;p(!0),s(null),await r(t)||s("Master Parola yanlış veya doğrulanamadı."),p(!1)},S=async()=>{await B(),window.location.href="/login"},h=typeof chrome<"u"&&!!chrome.runtime&&!!chrome.runtime.id&&window.location.protocol==="chrome-extension:";return e.jsx("div",{className:`auth-container ${h?"":"web-mode"}`,children:e.jsxs("div",{className:"auth-content-wrapper",children:[!h&&e.jsxs("div",{className:"auth-header-external",children:[e.jsx("div",{className:"auth-header-logo",children:"🔒"}),e.jsx("h1",{className:"auth-header-title",children:"Kasa Kilitli"}),b&&e.jsx("div",{className:"auth-header-subtitle",children:e.jsx("b",{children:b})})]}),e.jsxs("div",{className:"auth-box",children:[h&&e.jsxs("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:"24px"},children:[e.jsx("div",{style:{width:"56px",height:"56px",borderRadius:"50%",background:"var(--primary)",color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"24px",marginBottom:"12px"},children:"🔒"}),b?e.jsxs(e.Fragment,{children:[e.jsx("h3",{style:{margin:0,fontSize:"16px"},children:b}),e.jsx("p",{style:{color:"var(--text-secondary)",fontSize:"12px",margin:"4px 0 0 0"},children:"Kasa Kilitli"})]}):e.jsx("h3",{style:{margin:0},children:"Kasa Kilitli"})]}),!b&&e.jsx("div",{style:{textAlign:"center",marginBottom:"20px"},children:e.jsx("p",{style:{color:"var(--text-secondary)"},children:"Devam etmek için Master Parolanızı girin."})}),u&&e.jsx("div",{className:"alert alert-error",children:u}),e.jsxs("form",{onSubmit:x,children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"masterPassword",children:"Master Parola"}),e.jsx("input",{id:"masterPassword",type:"password",value:t,onChange:f=>l(f.target.value),placeholder:"Giriş yapmak için parolanızı girin",required:!0,autoFocus:!0})]}),e.jsx("button",{type:"submit",className:"btn btn-primary btn-block",disabled:a,children:a?"Doğrulanıyor...":"Kilidi Aç"})]}),e.jsx("div",{className:"auth-footer",children:e.jsx("button",{onClick:S,className:"btn-link",style:{color:"var(--text-secondary)"},children:"Farklı bir hesapla giriş yap"})})]})]})})},K=({children:r})=>{const t=localStorage.getItem("authToken"),{isLocked:l}=T();return t?l?e.jsx(me,{}):e.jsx(e.Fragment,{children:r}):e.jsx(ae,{to:"/login",replace:!0})},ue=()=>e.jsxs(Q,{children:[e.jsx(v,{path:"/login",element:e.jsx(J,{})}),e.jsx(v,{path:"/register",element:e.jsx(X,{})}),e.jsx(v,{path:"/download",element:e.jsx(ce,{})}),e.jsx(v,{path:"/",element:e.jsx(K,{children:e.jsx(ie,{})})}),e.jsx(v,{path:"/passwords/add",element:e.jsx(K,{children:e.jsx(O,{})})}),e.jsx(v,{path:"/passwords/:id",element:e.jsx(K,{children:e.jsx(le,{})})}),e.jsx(v,{path:"/passwords/:id/edit",element:e.jsx(K,{children:e.jsx(oe,{})})}),e.jsx(v,{path:"/settings",element:e.jsx(K,{children:e.jsx(ee,{})})}),e.jsx(v,{path:"*",element:e.jsx(de,{})})]}),Y=()=>{const r=localStorage.getItem("encryptionKey"),t=localStorage.getItem("authToken"),l=localStorage.getItem("userName");return{encryptionKey:{exists:!!r,length:r?.length,preview:r?.substring(0,32)+"..."},authToken:{exists:!!t,preview:t?.substring(0,32)+"..."},userName:{exists:!!l,value:l},allKeys:Object.keys(localStorage)}};typeof window<"u"&&(window.__debugCrypto=Y);typeof window<"u"&&(window.__debugCrypto=Y,console.log("💡 Debug mode: console'da __debugCrypto() çağırarak state kontrol edebilirsin"));function he(){const[r,t]=d.useState(!1);return d.useEffect(()=>{(async()=>{if(typeof chrome<"u"&&chrome.storage?.local&&!localStorage.getItem("authToken"))try{const a=await chrome.storage.local.get(["authToken","userName","userId","encryptionKeyCheck","kdfSalt","kdfIterations","vaultTimeout","vaultAction","lockOnBrowserClose","lockOnSystemLock"]);a.authToken&&(localStorage.setItem("authToken",a.authToken),a.userName&&localStorage.setItem("userName",a.userName),a.userId&&localStorage.setItem("userId",a.userId),a.encryptionKeyCheck&&localStorage.setItem("encryptionKeyCheck",a.encryptionKeyCheck),a.kdfSalt&&localStorage.setItem("kdfSalt",a.kdfSalt),a.kdfIterations&&localStorage.setItem("kdfIterations",String(a.kdfIterations)),a.vaultTimeout&&localStorage.setItem("vaultTimeout",String(a.vaultTimeout)),a.vaultAction&&localStorage.setItem("vaultAction",a.vaultAction),a.lockOnBrowserClose&&localStorage.setItem("lockOnBrowserClose",String(a.lockOnBrowserClose)),a.lockOnSystemLock&&localStorage.setItem("lockOnSystemLock",String(a.lockOnSystemLock)),console.log("✅ Auth token restored from chrome.storage.local"))}catch(a){console.warn("Storage sync error:",a)}t(!0)})()},[]),r?e.jsx("div",{className:"app",children:e.jsx(se,{children:e.jsx(re,{children:e.jsx(ne,{children:e.jsx(ue,{})})})})}):null}te.createRoot(document.getElementById("root")).render(e.jsx(d.StrictMode,{children:e.jsx(he,{})}));
